import logo from './logo.svg';
import './App.css';
//. 로 시작하는 경우는 사용자가만든 폴더나 파일
//node_modules 폴더에 있는 것들은 이렇게 접근  
import 'bootstrap/dist/css/bootstrap.min.css';
import Layout from './component/layout';
import Home from './component/home';
import { Route, Routes } from 'react-router-dom';
import HeroList from './component/hero/heroList';
import HeroView from './component/hero/heroView';
import NoMatch from './component/nomatch';
import GetUserInfo from './component/getUserInfo';
import Score from './component/score';

function App() {
  return (
    <div className="container-fluid">
      {/* 화면에 보여지지는 않는다. url => 어떤 컴포넌트가 호출될것인가 
         컴포넌트를 특정 url로 호출하고 싶다. 
          Routes 에 다 선언이 되어야 한다 
          Route 는 페이지의 전체적인 구조 선언 
          path="/" 이 url 로 시작할경우에 Layout컴포넌트에서 처리한다 

        <Route path="/" element={<Layout/>} >   /  ===> Layout컴포넌트가 처리
          //상세페이지들 페이지들이 들어간다  
          <Route index element={<Home/>} />     index  ==> /
          index의 경우에는 부모 url이 내꺼가 된다. 

          <Route path="/hero/list" element={<HeroList/>} />  
          /hreo/list =>    HeroList라는 컴포넌트로 교체된다. 
          <Outlet/> <= 컴포넌트로 바뀌치기 한다  
        </Route>

        /hero/view/:id => /hero/view/1 

        /add/4/5  ==> Add라는 컴포넌트를 만들고 라우트추가 
        4 + 5 = 9
      */}
      <Routes>
        <Route path="/" element={<Layout/>} >
          <Route index element={<Home/>} />
          <Route path="/hero/list" element={<HeroList/>} />
          <Route path="/hero/view/:id" element={<HeroView/>} />
          <Route path="/getUserInfo" element={<GetUserInfo/>} />
          <Route path="/score" element={<Score/>} />
          <Route path="*" element={<NoMatch/>} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;
