import { useParams } from "react-router-dom";

//   /hero/view/1   => id값은 어떻게 받을까  
function HeroView() {
    let {id} = useParams();//파라미터 받아오는 훅 
    
    return ( <div>
        <h1>{id}</h1>
    </div> );
}

export default HeroView;