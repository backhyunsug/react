
//메인 골격 디자인 파일-전체적인 윤곽을 만든다. 
import { Outlet, NavLink} from "react-router-dom";
function Layout() {
    let activestyle={
        color:"green",
        fontSize:"2rem"
    }

    return ( 
        <>
            {/*  to가 Route정의할때 path부분에 정의된 url을 to구문에 적는다 
                a 태그는 외부로 나갈때 내부에서 SPA(Single Page Application)
                은 한곳을 고정시켜놓고 나머지 부분을 바뀌치기 
                <Oultlet/>  Link나 NavLink도 사용가능하다 
                NavLink activestyle 속성이 있다가 없어졌음 = 
                선택된 메뉴가 있으면 그게 하이라이트를 줄 수 있다
                isActive NavLink안에 
            */}
            <nav className="navbar navbar-expand-sm bg-secondary navbar-dark">
                <div className="container-fluid">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                        <NavLink   style={({ isActive }) =>
                            isActive ? activestyle : undefined
                            } className="nav-link" to="/">Home</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink  className="nav-link" to="/hero/list">영웅들</NavLink>
                        </li>
                    </ul>
                </div>
            </nav>

            <Outlet style={ {"marginTop":"20px"}}/>
        </>
    );
}

export default Layout;