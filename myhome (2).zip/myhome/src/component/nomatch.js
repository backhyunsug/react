function NoMatch() {
    return ( <div>
        <h1>일치하는 페이지가 없습니다</h1>
    </div> );
}

export default NoMatch;