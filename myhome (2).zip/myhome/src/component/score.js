import { useState } from "react";
import axios from "axios";

function Score() {
    const [userInfo, setUserInfo] = useState({});
    const {name, kor, eng, mat } = userInfo;

    const nameChange=(e)=> { setUserInfo({...userInfo, name:e.target.value})};
    const korChange=(e)=> { setUserInfo({...userInfo, kor:e.target.value})};
    const engChange=(e)=> { setUserInfo({...userInfo, eng:e.target.value})};
    const matChange=(e)=> { setUserInfo({...userInfo, mat:e.target.value})};
   
    const sendData = async ()=>{
        let result = await axios.post("http://127.0.0.1:8080/score", userInfo);
        console.log( result.data );

    }
    return (<div>
        이름 : <input type="text" value={name} onChange={nameChange}/><br/>
        국어 : <input type="text" value={kor} onChange={korChange}/><br/>
        영어 : <input type="text" value={eng} onChange={engChange}/><br/>
        수학 : <input type="text" value={mat} onChange={matChange}/><br/>
        <button type="button" onClick={sendData} >결과확인</button>
    </div>  );
}

export default Score;