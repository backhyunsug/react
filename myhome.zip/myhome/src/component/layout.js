
//메인 골격 디자인 파일-전체적인 윤곽을 만든다. 
import { Outlet, NavLink, Link } from "react-router-dom";
function Layout() {
    return ( 
        <>
            <nav className="navbar navbar-expand-sm bg-secondary navbar-dark">
                <div className="container-fluid">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <Link className="nav-link active" to="/">Home</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/hero/list">영웅들</Link>
                        </li>
                    </ul>
                </div>
            </nav>

            <Outlet style={ {"marginTop":"20px"}}/>
        </>
    );
}

export default Layout;